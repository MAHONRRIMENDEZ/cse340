// Needed Resources 
const express = require("express")
const router = new express.Router() 
const invController = require("../controllers/invController")
const utilities = require("../utilities")

// Route to build inventory by classification view
///router.get("/type/:classificationId", invController.buildByClassificationId);
router.get("/type/:classificationId", utilities.handleErrors(invController.buildByClassificationId));


// Route to build vehicle detail view
///router.get("/detail/:invId", invController.buildByInvId)
router.get("/detail/:invId", utilities.handleErrors(invController.buildByInvId));


// Ruta para probar error 500
router.get("/detail/:invId3215", invController.triggerError)


module.exports = router;